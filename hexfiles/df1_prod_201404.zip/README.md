
`DF1_prod_v1.3.hex`
  
  First production hexfile. Contains 3 separate images : BIM, ImgA, ImgB. 
  ImgB is the running app, and can be updated by ImgA via OAD.
